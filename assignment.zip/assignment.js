const burger = document.querySelector(".burger");
const sidebar = document.querySelector(".sidebar");

burger.addEventListener("click", () => {
    sidebar.classList.toggle("sidebar-hidden");
})